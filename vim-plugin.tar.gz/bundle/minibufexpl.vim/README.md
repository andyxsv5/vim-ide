minibufexpl.vim
===============

minibufexpl.vim
