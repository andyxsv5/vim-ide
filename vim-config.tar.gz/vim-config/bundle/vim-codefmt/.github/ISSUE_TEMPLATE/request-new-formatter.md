---
name: Request new formatter
about: Submit a request for a formatter not already supported (or requested at https://bit.ly/3alNxjb)
title: ''
labels: new formatter
assignees: ''

---

**Formatter tool**
[Name of the tool and link to context]

**Filetype(s)**
[Applicable languages/filetypes you'd like to use this tool to format]

**Additional context**
[Add any other context or screenshots about the feature request here.]
